function calculateTotal() {
      // Get input values
      const movieSelect = document.getElementById('movie');
      const ticketInput = document.getElementById('tickets');
     
      const moviePrice = parseFloat(movieSelect.value);
      const numberOfTickets = parseInt(ticketInput.value);

      // Validate inputs
      if (!moviePrice || !numberOfTickets || numberOfTickets < 1) {
        alert('Please select a movie and enter a valid number of tickets');
        return;
      }

      // Calculate subtotal
      const subtotal = moviePrice * numberOfTickets;
     
      // Calculate discount if applicable (10% for 3 or more tickets)
      let discount = 0;
      if (numberOfTickets >= 3) {
        discount = subtotal * 0.1;
      }

      // Calculate final total
      const finalTotal = subtotal - discount;

      // Format currency for Indian Rupees
      const formatINR = (amount) => {
        return new Intl.NumberFormat('en-IN', {
          style: 'currency',
          currency: 'INR',
          minimumFractionDigits: 2,
          maximumFractionDigits: 2
        }).format(amount);
      };

      // Update the summary section with INR formatting
      document.getElementById('moviePrice').textContent = formatINR(moviePrice);
      document.getElementById('ticketCount').textContent = numberOfTickets;
      document.getElementById('subtotal').textContent = formatINR(subtotal);
      document.getElementById('discountAmount').textContent = formatINR(discount);
      document.getElementById('total').textContent = formatINR(finalTotal);

      // Show summary section
      document.getElementById('summary').classList.remove('hidden');
     
      // Show/hide discount line based on whether there is a discount
      const discountElement = document.querySelector('.discount');
      if (discount > 0) {
        discountElement.classList.remove('hidden');
      } else {
        discountElement.classList.add('hidden');
      }

      // Add animation effect
      const summary = document.getElementById('summary');
      summary.style.animation = 'none';
      summary.offsetHeight; // Trigger reflow
      summary.style.animation = 'fadeIn 0.5s ease-in-out';
    }

    // Add keypress event listener for the Enter key
    document.getElementById('tickets').addEventListener('keypress', function(event) {
      if (event.key === 'Enter') {
        calculateTotal();
      }
    });